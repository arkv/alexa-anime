var alexa = require('alexa-app');
var app = new alexa.app();
var rp = require('request');
var cheerio = require('cheerio');
var page = Math.floor(Math.random() * 26057);

rp("https://myanimelist.net/anime/" + page, function(error, response, html) {
  if(error) {
    console.log("Error: " + error);
  }
  console.log("Status code: " + response.statusCode);

	var $ = cheerio.load(html);
	var title = $('head > title').text().trim().replace('MyAnimeList.net','');
	 console.log("title:" + title);
	 })
	
app.launch(function(req, res){
 res.say("Whaddup this the test app stay comfy homes");
 res.shouldEndSession(false);
})
app.intent('GetAnimeSuggestions',
 {
  "slots": {},
  "utterances": [
   "Suggest a random anime",
   "test foundation now"
  ]
 },
 function (req, res) {
  generate_suggestions(response);
  return; 
 }
);
function generate_suggestions(response){
res.say("How about the anime" + title + "?");
 res.send();
return ;
}
// Connect to lambda
exports.handler = app.lambda();
if ((process.argv.length === 3) && (process.argv[2] === 'schema'))
{
    console.log (app.schema ());
    console.log (app.utterances ());
}